Steps:

1. Start the program by running start.py using the following command

python start.py

2. Click on the Open Cam button to open the camera for capturing the patient posture

3. Machine learning algorithm performs its computations on the captured image and classifies
   the picture as Safe or Unsafe to lift.
   label_image.py program takes care of these operations.
   As we have used the pretrained model of Google inception v3, further details of implementation
   is not provided here.

Description about the folders:

1. scripts: This folder contains the files required for performing operations that helps in classifying the captured image
   The file which takes the image as input is label_image.py which can be accessed by running the following command

   python -m scripts.label_image --image=tf_files/Test/image53.jpg

   For this command to run, you need to have a Test folder with a test image (here named image53.jpg) in the tf_files folder provided

   Remaining files are called via this file whose implementation and functioning is not up-to my knowledge. But the whole
   purpose of remaining all files is for classification of the image

2. tf_files: This folder contains the folders and files which are created from training.
   After the completion of training, the algorithm creates two files which are used for classification in label_image.py file. Those files are:
   a.retrained_graph
   b.retrained_labels

   bottlenecks and training_summaries are the folders created during training which saved the training details at intervals of time during training
   Models has the inception v3 model implementation files which is the main resource for training

   The command used for training is:
   python -m scripts.retrain \
  --how_many_training_steps=4000 \
  --bottleneck_dir=tf_files/bottlenecks \
  --model_dir=tf_files/models/"${ARCHITECTURE}" \
  --summaries_dir=tf_files/training_summaries/"${ARCHITECTURE}" \
  --output_graph=tf_files/retrained_graph.pb \
  --output_labels=tf_files/retrained_labels.txt \
  --image_dir=tf_files/Human_pose

  You need to have 'Human_pose' directory with 2 folders named Positive and Negative which are the class names
  These two directories need to have the images of respected classes

Requirements:

Install tensorflow GPU, OpenCV, Tkinter which are the main packages needed.
Install the remaining basic modules like numpy,PIL etc
