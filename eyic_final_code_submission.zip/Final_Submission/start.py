#
                            #
                            # Project Name:  Design and Developmemet of Hydraulically Actuated Autonomous Nurse
                            # Author List: 	Kaushik Balasundar,Aby J Kottoor,Akash S Nambiar,Shwetha D
                            # Filename: start.py
                            # Functions: hel(),contri(),anotherWin(),web(),exitt() and Class App and Class MyVideoCapture private functions
                            # Global Variables:	root,frame,label,filename,background_label,menu,subm1,subm2

#
#Required models for performing the operations


import PIL.Image, PIL.ImageTk
import numpy as np
import os
import time
from pygame import mixer
import time
import cv2
from tkinter import *
import tkinter.messagebox



root=tkinter.Tk() #creates a tkinter window
root.geometry('500x570') #sets the window size
frame = Frame(root, relief=RIDGE, borderwidth=2) #used for managing the widgets created
frame.pack(fill=BOTH,expand=1)
root.title('HYAAN') #gives a title to the window
frame.config(background='light blue') #sets background colour
label = Label(frame, text="HYAAN",bg='light blue',font=('Times 35 bold'))
label.pack(side=TOP)
filename = PhotoImage(file="demo.png") #background image
background_label = Label(frame,image=filename)
background_label.pack(side=TOP)

 #
                            #
                            # Function Name: 	hel()
                            # Input: 		None
                            # Output: 		None
                            # Logic: 		Opens the help page given by cv2
                            # Example Call:		hel()
                            #
#
def hel():
   help(cv2)
#
                           #
                           # Function Name: 	Contri()
                           # Input: 		None
                           # Output: 		None
                           # Logic: 		Opens a small message box displaying the Contributors to the Project
                           # Example Call:		Contri()
                           #
#
def Contri():
   tkinter.messagebox.showinfo("Contributors","\n1.Kaushik Balasundar\n2. Aby J Kottur \n3. Shwetha D \n4. Akash \n")

#
                           #
                           # Function Name: 	anotherWin()
                           # Input: 		None
                           # Output: 		None
                           # Logic: 		Opens a small message box displaying the information about how this page is made
                           # Example Call:		anotherWin()
                           #
#

def anotherWin():
   tkinter.messagebox.showinfo("About",'HYAAN version v1.0\n Made Using\n-OpenCV\n-Numpy\n-Tkinter\n In Python 3')


menu = Menu(root) #creates a menu
root.config(menu=menu) # Adds the menu to the window created

subm1 = Menu(menu) #creates a submenu in main menu
menu.add_cascade(label="Tools",menu=subm1) # Add the contents to the main menu
subm1.add_command(label="Open CV Docs",command=hel) # Add the contents to the submenu with the command of hel() function on click of this option

subm2 = Menu(menu) #creates a submenu in main menu
menu.add_cascade(label="About",menu=subm2) # Add the contents to the main menu
subm2.add_command(label="HYAAN",command=anotherWin) # Add the contents to the submenu with the command of anotherWin() function on click of this option
subm2.add_command(label="Contributors",command=Contri) # Add the contents to the submenu with the command of Contri() function on click of this option
class MyVideoCapture:
    def __init__(self, video_source=0):

        # Open the video source
        self.vid = cv2.VideoCapture(video_source) #Opens the camera--opens webcam if video_source is 0 else if video_source is 1 opens the camera attached to the laptop
        if not self.vid.isOpened():
            raise ValueError("Unable to open video source", video_source)

          # Get video source width and height
        self.width = self.vid.get(cv2.CAP_PROP_FRAME_WIDTH) #gets the video width which is equal to camera resolution
        self.height = self.vid.get(cv2.CAP_PROP_FRAME_HEIGHT) #gets the video height which is equal to camera resolution
    def __del__(self):
        if self.vid.isOpened():
            self.vid.release() #deletes the window
        self.window.mainloop() #keeps the window open
    def get_frame(self):
        if self.vid.isOpened():
            ret, frame = self.vid.read() #reads the video frames one by one
            if ret:
                return (ret, cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
            else:
                return (ret, None)
        else:
            return (ret, None)
class App:
    def __init__(self, window, window_title, video_source=0):
        self.window = window
        self.window.title(window_title)
        self.video_source = video_source

        # open video source
        self.vid = MyVideoCapture("http://192.168.43.249:8080/video")
        #self.vid = MyVideoCapture(video_source)
        # Create a canvas that can fit the above video source size
        self.canvas = tkinter.Canvas(window, width = self.vid.width, height = self.vid.height-300)
        self.canvas.pack()
        self.btn_snapshot=tkinter.Button(window, text="Snapshot", width=50, command=self.snapshot)
        self.btn_snapshot.pack(anchor=tkinter.CENTER, expand=True)
        self.delay = 15
        self.update()

        self.window.mainloop()
    #This function is required for updating the frames in the window
    def update(self):
        # Get a frame from the video source
        ret, frame = self.vid.get_frame()

        if ret:
            self.photo = PIL.ImageTk.PhotoImage(image = PIL.Image.fromarray(frame))
            self.canvas.create_image(0, 0, image = self.photo, anchor = tkinter.NW)
        self.window.after(self.delay, self.update)
#This function is required for capturing the frame that is captured when the button is clicked
    def snapshot(self):
        # Get a frame from the video source
        ret, frame = self.vid.get_frame()
        if ret:
            cv2.imwrite("frame_test.jpg", cv2.cvtColor(frame, cv2.COLOR_RGB2BGR)) #Saves the image captured on button click
            self.window.destroy()
            self.window = tkinter.Tk()
            self.cv_img = cv2.cvtColor(cv2.imread("frame_test.jpg"), cv2.COLOR_BGR2RGB)
            self.height, self.width, self.no_channels = self.cv_img.shape
            self.canvas = tkinter.Canvas(self.window, width = self.width, height = self.height)
            self.canvas.pack()
            self.photo = PIL.ImageTk.PhotoImage(image = PIL.Image.fromarray(self.cv_img))
            self.canvas.create_image(0, 0, image=self.photo, anchor=tkinter.NW)
            self.delay = 15
            self.window.after(self.delay, self.label)
            self.window.mainloop()

    def label(self):
        self.window.destroy()
        os.system('python -m scripts.label_image --image=frame_test.jpg') #calls other program which does machine learning computations on the sent image to decide whether the patients posture is safe to lift or not

#
                           #
                           # Function Name: 	exitt()
                           # Input: 		None
                           # Output: 		None
                           # Logic: 		exits the window
                           # Example Call:		exitt()
                           #
#
def exitt():
   exit()
#
                           #
                           # Function Name: 	web()
                           # Input: 		None
                           # Output: 		None
                           # Logic: 		opens the camera for capturing the iamge of the patient.
                           # Example Call:		web()
                           #
#

def web():
   root.destroy()
   App(tkinter.Tk(), "HYAAN-") #Creates an instance of the class App which creates a tkinter window






but1=Button(frame,padx=5,pady=5,width=39,bg='white',fg='black',relief=GROOVE,command=web,text='Open Cam',font=('helvetica 15 bold')) #creates a button in the main tkinter window with the styles specified in the arguments
but1.place(x=5,y=200) # sets the positon of the button by specifying x and y co-ordinates
but1=Button(frame,padx=5,pady=5,width=39,bg='white',fg='black',relief=GROOVE,command=exitt,text='EXIT',font=('helvetica 15 bold'))
but1.place(x=5,y=300) # sets the positon of the button by specifying x and y co-ordinates



root.mainloop() #keeps the tkinter main window open
